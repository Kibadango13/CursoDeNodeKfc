const config = require('config');
const mongoose = require('mongoose')
const chai = require('chai');
const {MongoMemoryServer} = require('mongodb-memory-server');
const expect = chai.expect;
const assert = chai.assert;
chai.should();


describe('api/keywords/model',()=>{
   //se levanta un servidor mongo db 
   let mongoServer = new MongoMemoryServer();
   const {options} =config.get('database');
   before(async ()=>{
        const uri = await mongoServer.getConnectionString();
        console.log('MONGO_URI',uri);
        await mongoose.connect(uri,options);
   });


   after(async ()=>{
       await mongoose.disconnect();
       await mongoServer.stop();
   })

    it('should create a keyword',()=>{
            expect(true).to.be.true;
    })
})